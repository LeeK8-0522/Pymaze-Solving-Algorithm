dependency: 
- numpy 1.21.6
- matplot 3.5.4

How to run?
Set parameters values as you like and just run 'q_learning_test.py'!

If you run the code, experiment result will be printed in 'result.txt' file.